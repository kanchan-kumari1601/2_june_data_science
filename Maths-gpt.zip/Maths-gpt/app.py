from flask import Flask, render_template, request
import openai
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/", methods=["GET", "POST"])
def index():
    response = ""
    if request.method == "POST":
        user_input = request.form["problem"]
        prompt = f"Solve this math problem step by step: {user_input}"
        try:
            completion = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful math tutor."},
                    {"role": "user", "content": prompt}
                ]
            )
            response = completion.choices[0].message["content"]
        except Exception as e:
            response = "Error: " + str(e)
    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(debug=True)